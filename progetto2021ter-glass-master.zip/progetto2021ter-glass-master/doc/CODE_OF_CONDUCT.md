# CONTRATTO


## PROGETTO

- il lavoro deve essere realizzato seguendo le linee guida imposte.
- deve essere frequente la revisione del progetto.
- le modalità di lavoro saranno professionali.
- è necessario rispettare le critiche altrui.
- ognuno dovrà impegnarsi per un codice ben chiaro.
- è obbligatorio testare sempre il codice del progetto.
- il codice deve essere sempre funzionante.
- elimazione e debugging dei warning.



## PARTECIPAZIONE

- il seguente contratto è valido per ogni membro del gruppo.
- le attività svolte in gruppo devono essere condivise coi membri.
- non è possibile condividere informazioni con altri team di lavoro.
- ogni componente deve rispettare i tempi.
- ci dovrà essere aiuto reciproco tra i membri del gruppo.

package it.uniba.main.costanti;

/**
 * Tipologia della classe: <b> << entity class >> </b> <br>
 * Responsabilita' della classe: costanti utilizzate durante i controlli di movimento
 */
public final class Numero {

    private Numero() {

    }

    public static final int N0 = 0;
    public static final int N1 = 1;
    public static final int N2 = 2;
    public static final int N3 = 3;
    public static final int N4 = 4;
    public static final int N5 = 5;
    public static final int N6 = 6;
    public static final int N7 = 7;
    public static final int N8 = 8;
    public static final int N9 = 9;
    public static final int N10 = 10;
    public static final int N11 = 11;
    public static final int N12 = 12;
    public static final int N13 = 13;
    public static final int N14 = 14;
    public static final int N15 = 15;
    public static final int N16 = 16;
    public static final int N17 = 17;
    public static final int N18 = 18;
    public static final int N19 = 19;
    public static final int N20 = 20;
    public static final int N21 = 21;
    public static final int N22 = 22;
    public static final int N23 = 23;
    public static final int N24 = 24;
    public static final int N25 = 25;
    public static final int N26 = 26;
    public static final int N27 = 27;
    public static final int N28 = 28;
    public static final int N29 = 29;
    public static final int N30 = 30;
    public static final int N31 = 31;
    public static final int N32 = 32;

}
